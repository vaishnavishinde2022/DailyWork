package com.application.repository;

import org.springframework.data.repository.CrudRepository;

import com.application.entities.Instructor;

public interface InstrctoreRepo extends CrudRepository<Instructor,Integer>
{

}
