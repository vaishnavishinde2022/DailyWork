package com.application.repository;

import org.springframework.data.repository.CrudRepository;

import com.application.entities.InstrctorDetails;

public interface InstrctoreDetailsRepo extends CrudRepository<InstrctorDetails,Integer>
{

}
