package conditionalsPracticePackage1;

public class ExampleOfIf
{
  public static void main(String[] args)
  {
	  
	 String my_condigstatus="Getting Good";
	 
	 if(my_condigstatus.equals("Getting Good"))
	 {
		 System.out.println("I am glad to hear that");
	 }//if
	 
	 else
	 {
		 System.out.println("Dont'worry,you will get better soon!"); 
	 }//else
	  
	  
  }
}
