package com.first;

import org.springframework.data.repository.CrudRepository;



public interface UserRepository extends CrudRepository<User,Integer>
{

}
